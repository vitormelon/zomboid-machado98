Backup time: 2022-09-25 at 13:21:10 GMT
ServerName: ZomboidServer
Current server version:41.73
Current world version:194
World version in this backup is:World isn't exist