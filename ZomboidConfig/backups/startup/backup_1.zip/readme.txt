Backup time: 2022-09-25 at 13:25:49 GMT
ServerName: ZomboidServer
Current server version:41.73
Current world version:194
World version in this backup is:194